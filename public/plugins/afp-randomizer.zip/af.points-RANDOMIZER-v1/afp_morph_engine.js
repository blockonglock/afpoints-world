// afp_morph_engine.js
// af.points RANDOMIZER — Core Engine
// Runs inside jsui for reliable file loading in Max for Live
//
// Messages (all via inlet 0):
//   spawn       → capture/randomize snapshot
//   morph <f>   → set morph value (0 = full A, 1 = full B)
//   init        → reset state
// Outlet 0: symbol → indicator ("indicator" "A"/"B"/"none")
// Outlet 1: symbol → target device name ("target" <name>)
// Outlet 2: float  → morph dial feedback (auto-jump after SPAWN)

outlets = 3;

// ===== JSUI MINIMAL SETUP (engine-only, no visual) =====
mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

function paint() {
    // No visual output — this jsui is an invisible engine
}

// ============================================================
// STATE
// ============================================================

var nextSlot = "A";         // which slot the NEXT spawn will write
var slotA = null;           // float[] — random state A
var slotB = null;           // float[] — random state B
var slotBaseline = null;    // float[] — original state (captured on first SPAWN)
var morphValue = 0.5;       // 0 = full A, 0.5 = baseline, 1 = full B
var paramEntries = [];      // {id, name, min, max, quantized, api}[]
var paramApis = [];         // cached LiveAPI objects (1:1 with paramEntries)

// --- device targeting ---
var myTrackPath = "";       // canonical path to our track, e.g. "live_set tracks 2"
var myId = 0;               // our own device ID (to filter self)
var lastDeviceId = 0;       // last valid target device ID (updated by observer)
var lastDeviceName = "";    // last valid target device name (for UI)
var enumeratedDeviceId = 0; // device ID for which paramEntries was built
var deviceObserver = null;  // LiveAPI observer on Track.View.selected_device
var deviceCheckTask = null; // deferred task for observer callback

// ============================================================
// BANNED PARAMETER NAME PATTERNS
// ============================================================
// Case-insensitive. Word-boundary (\b) prevents false positives
// e.g. "Tone" does NOT match /\bon\b/, "Freeze" does NOT match /\bfree\b/

// ============================================================
// MORPH THROTTLE CONFIG
// ============================================================
var MORPH_INTERVAL_MS = 50;       // ms between morph apply cycles (was 25)

var BANNED = [
    // --- bypass / on / enable ---
    /bypass/i,
    /^device\s+on$/i,
    /\bon\b/i,
    /\benable/i,

    // --- output levels / volume ---
    /\bvolume\b/i,
    /\bvol\b/i,
    /\bgain\b/i,
    /output/i,
    /\bout\b/i,
    /\bmaster\b/i,
    /\btrim\b/i,
    /makeup/i,
    /ceiling/i,

    // --- quality / processing ---
    /quality/i,
    /oversampl/i,
    /latency/i,
    /lookahead/i,

    // --- sync / time-mode selectors ---
    /\bsync\b/i,
    /\btempo\b/i,
    /\bhost\b/i,
    /\bfree\b/i,
    /\bms\b/i,
    /\bbeats\b/i,
    /\bnote\b/i,
    /division/i,

    // --- mix / dry-wet ---
    /\bmix\b/i,
    /dry.?wet/i
];

function isBanned(name) {
    for (var i = 0; i < BANNED.length; i++) {
        if (BANNED[i].test(name)) return true;
    }
    return false;
}

// ============================================================
// HELPERS
// ============================================================

function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
}

function extractId(apiResult) {
    var str = apiResult.toString();
    var nums = str.match(/\d+/g);
    if (!nums) return 0;
    var id = parseInt(nums[nums.length - 1]);
    return isNaN(id) ? 0 : id;
}

function cleanPath(api) {
    var p = api.path;
    if (typeof p === "string") return p.replace(/"/g, "");
    return String(p).replace(/"/g, "");
}

// ============================================================
// DEVICE TARGETING
// Observer on Track.View.selected_device keeps lastDeviceId
// up-to-date in real time. resolveTarget() just validates it.
// See: https://docs.cycling74.com/apiref/lom/track_view
// ============================================================

// --- Observer callback (fires when user clicks on any device) ---
function onSelectedDeviceChanged() {
    // Defer actual API calls to avoid "Changes cannot be triggered
    // by notifications" restriction
    if (!deviceCheckTask) deviceCheckTask = new Task(checkSelectedDevice, this);
    deviceCheckTask.cancel();
    deviceCheckTask.schedule(50);
}

// --- Deferred check: read the currently selected device ---
function checkSelectedDevice() {
    if (myTrackPath === "") return;
    try {
        var selApi = new LiveAPI(myTrackPath + " view selected_device");
        var selId = parseInt(selApi.id);

        if (selId !== 0 && selId !== myId) {
            // Valid target — update
            lastDeviceId = selId;
            lastDeviceName = selApi.get("name").toString();
            updateTargetDisplay();
            post("af.points RANDOMIZER: target -> [" + lastDeviceName + "]\n");
        } else if (selId === 0) {
            // No device selected (all removed?) — clear target
            lastDeviceId = 0;
            lastDeviceName = "";
            enumeratedDeviceId = 0;
            disposeParamApis();
            paramEntries = [];
            slotA = null;
            slotB = null;
            slotBaseline = null;
            nextSlot = "A";
            updateTargetDisplay();
            updateIndicator();
        } else if (selId === myId && lastDeviceId !== 0) {
            // User clicked on us — verify old target still exists
            try {
                var checkApi = new LiveAPI("id " + lastDeviceId);
                if (parseInt(checkApi.id) === 0) {
                    // Old target gone — clear
                    lastDeviceId = 0;
                    lastDeviceName = "";
                    enumeratedDeviceId = 0;
                    disposeParamApis();
                    paramEntries = [];
                    slotA = null;
                    slotB = null;
                    slotBaseline = null;
                    nextSlot = "A";
                    updateTargetDisplay();
                    updateIndicator();
                }
            } catch (e2) {}
        }
    } catch (e) {}
}

// --- Start observing Track.View.selected_device ---
function startDeviceObserver() {
    if (myTrackPath === "") return;
    try {
        deviceObserver = new LiveAPI(onSelectedDeviceChanged, myTrackPath + " view");
        deviceObserver.property = "selected_device";
        post("af.points RANDOMIZER: observing selected_device on [" + myTrackPath + "]\n");
    } catch (e) {
        post("af.points RANDOMIZER: observer setup error: " + e + "\n");
    }
}

// --- Auto-detect: find the first non-self device (prefer left neighbor) ---
function autoDetectTarget() {
    if (myTrackPath === "") return;
    try {
        var trackApi = new LiveAPI(myTrackPath);
        var numDevices = trackApi.getcount("devices");

        // Find our position in the chain
        var myIndex = -1;
        for (var i = 0; i < numDevices; i++) {
            var devApi = new LiveAPI(myTrackPath + " devices " + i);
            if (parseInt(devApi.id) === myId) {
                myIndex = i;
                break;
            }
        }

        // Prefer left neighbor
        if (myIndex > 0) {
            var leftApi = new LiveAPI(myTrackPath + " devices " + (myIndex - 1));
            var leftId = parseInt(leftApi.id);
            if (leftId !== 0) {
                lastDeviceId = leftId;
                lastDeviceName = leftApi.get("name").toString();
                updateTargetDisplay();
                post("af.points RANDOMIZER: auto-target left neighbor [" + lastDeviceName + "]\n");
                return;
            }
        }

        // No left neighbor — try any non-self device
        for (var i = 0; i < numDevices; i++) {
            var devApi = new LiveAPI(myTrackPath + " devices " + i);
            var devId = parseInt(devApi.id);
            if (devId !== 0 && devId !== myId) {
                lastDeviceId = devId;
                lastDeviceName = devApi.get("name").toString();
                updateTargetDisplay();
                post("af.points RANDOMIZER: auto-target [" + lastDeviceName + "]\n");
                return;
            }
        }
    } catch (e) {
        post("af.points RANDOMIZER: auto-detect error: " + e + "\n");
    }
}

// --- resolveTarget: just validate lastDeviceId (observer keeps it fresh) ---
function resolveTarget() {
    if (lastDeviceId !== 0) {
        try {
            var api = new LiveAPI("id " + lastDeviceId);
            if (parseInt(api.id) !== 0) {
                return lastDeviceId;
            }
        } catch (e) {}
    }
    lastDeviceId = 0;
    lastDeviceName = "";
    updateTargetDisplay();
    return 0;
}

// ============================================================
// MESSAGE HANDLERS (all arrive on single inlet)
// ============================================================

// "spawn" message from SPAWN button
function spawn() {
    doSpawn();
}

// "morph <float>" message from MORPH dial
function morph(v) {
    processMorph(parseFloat(v));
}

// bang — also triggers spawn (for MIDI mapping convenience)
function bang() {
    doSpawn();
}

// ============================================================
// SPAWN — main action
// ============================================================

function doSpawn() {
    // 1. Resolve target device (observer keeps lastDeviceId fresh)
    var deviceId = resolveTarget();

    if (deviceId === 0) {
        post("af.points RANDOMIZER: Select a device on this track\n");
        outlet(0, "indicator", "none");
        return;
    }

    // 2. New target? Reset snapshots and re-enumerate params
    if (deviceId !== enumeratedDeviceId || paramEntries.length === 0) {
        enumeratedDeviceId = deviceId;
        slotA = null;
        slotB = null;
        slotBaseline = null;
        nextSlot = "A";
        paramEntries = [];
        enumerateParams(deviceId);
    }

    if (paramEntries.length === 0) {
        post("af.points RANDOMIZER: No manageable parameters found on [" + lastDeviceName + "]\n");
        return;
    }

    // 3. Capture baseline on first SPAWN (original device state)
    if (!slotBaseline) {
        slotBaseline = captureCurrentValues();
    }

    // 4. Generate random for the current slot + auto-jump morph
    var rnd = generateRandomValues();
    if (nextSlot === "A") {
        slotA = rnd;
        morphValue = 0.0;      // jump to full A so user hears the change
        nextSlot = "B";
    } else {
        slotB = rnd;
        morphValue = 1.0;      // jump to full B so user hears the change
        nextSlot = "A";
    }

    // 5. Apply morph and update dial position
    applyMorph();
    outlet(2, morphValue);      // feed back to dial (via "set $1" — no loop)

    // 6. Update indicator
    updateIndicator();

    post("af.points RANDOMIZER: SPAWN on [" + lastDeviceName + "] — next slot = " + nextSlot + "\n");
}

// ============================================================
// PARAMETER ENUMERATION
// ============================================================

function disposeParamApis() {
    // Release cached LiveAPI references
    for (var i = 0; i < paramApis.length; i++) {
        try { paramApis[i].id = 0; } catch (e) {}
    }
    paramApis = [];
}

function enumerateParams(deviceId) {
    disposeParamApis();

    var deviceApi = new LiveAPI("id " + deviceId);
    var deviceName = deviceApi.get("name");
    var numParams = deviceApi.getcount("parameters");
    var devPath = cleanPath(deviceApi);

    paramEntries = [];
    paramApis = [];

    for (var i = 0; i < numParams; i++) {
        try {
            var paramApi = new LiveAPI(devPath + " parameters " + i);
            var rawName = paramApi.get("name");
            var name = rawName ? rawName.toString() : "";

            if (isBanned(name)) continue;

            var pMin = parseFloat(paramApi.get("min"));
            var pMax = parseFloat(paramApi.get("max"));
            var paramId = parseInt(paramApi.id);

            var quantized = false;
            try {
                quantized = (parseInt(paramApi.get("is_quantized")) === 1);
            } catch (eq) {}

            if (isNaN(pMin) || isNaN(pMax) || pMin >= pMax) continue;
            if (isNaN(paramId) || paramId === 0) continue;

            // Cache a persistent LiveAPI object for this parameter
            var cachedApi = new LiveAPI("id " + paramId);

            paramEntries.push({
                id:        paramId,
                name:      name,
                min:       pMin,
                max:       pMax,
                quantized: quantized
            });
            paramApis.push(cachedApi);
        } catch (e) {}
    }

    post("af.points RANDOMIZER: " + paramEntries.length + " params on [" + deviceName + "]\n");
}

// ============================================================
// VALUE CAPTURE & RANDOM GENERATION
// ============================================================

function captureCurrentValues() {
    var vals = [];
    for (var i = 0; i < paramEntries.length; i++) {
        try {
            var v = parseFloat(paramApis[i].get("value"));
            vals.push(isNaN(v) ? paramEntries[i].min : v);
        } catch (e) {
            vals.push(paramEntries[i].min);
        }
    }
    return vals;
}

function generateRandomValues() {
    var vals = [];
    for (var i = 0; i < paramEntries.length; i++) {
        var p = paramEntries[i];
        var v = p.min + Math.random() * (p.max - p.min);
        if (p.quantized) v = Math.round(v);
        vals.push(v);
    }
    return vals;
}

// ============================================================
// MORPH — throttled parameter interpolation
// ============================================================

var morphDirty = false;
var morphThrottleActive = false;
var morphTask = null;  // lazy — created on first use to avoid jsui load crash

function processMorph(v) {
    morphValue = clamp(v, 0.0, 1.0);
    morphDirty = true;
    if (!morphThrottleActive) {
        doMorphCycle();
    }
}

function doMorphCycle() {
    if (!morphDirty) {
        morphThrottleActive = false;
        return;
    }
    morphDirty = false;
    morphThrottleActive = true;
    applyMorph();
    if (!morphTask) morphTask = new Task(doMorphCycle, this);
    morphTask.cancel();
    morphTask.schedule(MORPH_INTERVAL_MS);
}

function applyMorph() {
    if (!slotBaseline) return;
    if (paramEntries.length === 0) return;

    var m = morphValue;

    for (var i = 0; i < paramEntries.length; i++) {
        var base = slotBaseline[i];
        var p = paramEntries[i];
        var val;

        if (m <= 0.5) {
            // 0.0 → 0.5: A ↔ baseline
            if (slotA) {
                var t = m * 2.0;  // 0 at morph=0, 1 at morph=0.5
                val = slotA[i] + (base - slotA[i]) * t;
            } else {
                val = base;
            }
        } else {
            // 0.5 → 1.0: baseline ↔ B
            if (slotB) {
                var t = (m - 0.5) * 2.0;  // 0 at morph=0.5, 1 at morph=1.0
                val = base + (slotB[i] - base) * t;
            } else {
                val = base;
            }
        }

        if (p.quantized) val = Math.round(val);
        val = clamp(val, p.min, p.max);

        try {
            paramApis[i].set("value", val);
        } catch (e) {}
    }
}

// ============================================================
// INDICATOR + TARGET DISPLAY
// ============================================================

function updateIndicator() {
    // If no spawns yet (both slots null), send "none" so UI dims both A/B
    if (!slotA && !slotB) {
        outlet(0, "indicator", "none");
    } else {
        outlet(0, "indicator", nextSlot);
    }
}

function updateTargetDisplay() {
    if (lastDeviceName !== "") {
        outlet(1, "target", lastDeviceName);
    } else {
        outlet(1, "target", "no_target");
    }
}

// ============================================================
// INIT / RESET
// ============================================================

function init() {
    nextSlot = "A";
    slotA = null;
    slotB = null;
    slotBaseline = null;
    morphValue = 0.5;
    lastDeviceId = 0;
    lastDeviceName = "";
    enumeratedDeviceId = 0;
    disposeParamApis();
    paramEntries = [];

    // 1. Determine our own ID and track path
    try {
        var thisApi = new LiveAPI("this_device");
        myId = parseInt(thisApi.id);
        var trackId = extractId(thisApi.get("canonical_parent"));
        var trackApi = new LiveAPI("id " + trackId);
        myTrackPath = cleanPath(trackApi);
        post("af.points RANDOMIZER: init on track [" + myTrackPath + "], myId=" + myId + "\n");
    } catch (e) {
        myTrackPath = "";
        post("af.points RANDOMIZER: init — could not resolve track: " + e + "\n");
    }

    // 2. Auto-detect left neighbor as default target
    autoDetectTarget();

    // 3. Start observing Track.View.selected_device for real-time updates
    startDeviceObserver();

    updateIndicator();
    updateTargetDisplay();
    post("af.points RANDOMIZER engine ready\n");
}

function reset() {
    init();
}

function anything() {}
