# af.points RANDOMIZER v1

Max for Live device for Ableton Live.

RANDOMIZER controls another device on the same track. It captures the original state, creates randomized A/B states, and lets you move between them with the MORPH slider.

## Install

1. Unzip `af.points-RANDOMIZER-v1.zip`.
2. Keep the whole `af.points-RANDOMIZER-v1` folder together.
3. In Ableton Live, drag `af.points-RANDOMIZER-v1.amxd` onto an audio track.
4. Put the device you want to randomize on the same track.
5. Place RANDOMIZER to the right of the target device, or select the target device in Live.

## Important

Keep these files in the same folder:

- `af.points-RANDOMIZER-v1.amxd`
- `afp_morph_engine.js`
- `afp_randomizer_ui.js`

If the `.js` files are moved away from the `.amxd`, the device may load without its engine or UI.

## How To Use

1. Add a plugin or Live device to a track.
2. Add `af.points RANDOMIZER` on the same track.
3. Press `RANDOM`.
4. The first press creates A.
5. The second press creates B.
6. Move MORPH:
   - left = A
   - center = original state
   - right = B

## Troubleshooting

If the device says `NO TARGET`, select another device on the same track or place RANDOMIZER to the right of the device you want to control.

If nothing changes, try another target device. Some devices expose fewer parameters to Ableton Live, and RANDOMIZER skips risky controls such as gain, bypass, output, sync, and dry/wet.

## Requirements

- Ableton Live 11 or newer
- Max for Live / Max 8 or newer
