// afp_randomizer_ui.js
// Custom UI for af.points RANDOMIZER
// jsui + mgraphics for Max for Live
//
// Outlets:
//   0: bang  — fires on RANDOM button click (triggers spawn)
//   1: float — morph slider value (0.0–1.0)
//
// Inbound messages (all via inlet 0):
//   indicator <slot>    — which slot is NEXT ("A","B","none")
//   target <name...>    — target device name
//   set_morph <float>   — slider position (auto-jump from engine)
//   morph_fb <float>    — slider position (live.dial feedback)

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

outlets = 2;

// ============================================================
// DIMENSIONS
// ============================================================
var W = 320;
var H = 170;
var META_H = 28;
var SEP_Y = H - META_H;          // separator line Y

// ============================================================
// COLORS (0–1 float)
// ============================================================
var COL_WARM = [0.937, 0.376, 0.239];   // #EF603D — orange (DELAY signature)
var COL_COOL = [0.0, 0.706, 0.847];     // #00B4D8
var COL_TEXT = [0.067, 0.067, 0.067];    // #111111

// ============================================================
// BUTTON LAYOUT
// ============================================================
var BTN_W = 110;
var BTN_H = 26;
var BTN_X = (W - BTN_W) / 2;
var BTN_Y = 36;

// ============================================================
// MORPH ROW LAYOUT
// ============================================================
var MORPH_Y = 88;                  // vertical center
var IND_A_CX = 44;                 // A letter center X
var IND_B_CX = W - 44;            // B letter center X
var SLIDER_X1 = 76;               // track left edge
var SLIDER_X2 = W - 76;           // track right edge
var SLIDER_W = SLIDER_X2 - SLIDER_X1;
var THUMB_W = 6;
var THUMB_H = 16;

// ============================================================
// STATE
// ============================================================
var morphPos = 0.5;               // 0.0–1.0
var activeSlot = "none";          // "A", "B", or "none"
var targetName = "NO TARGET";     // display string
var isHoverBtn = false;
var isActiveBtn = false;
var isDragging = false;

// (noise overlay removed — clean gradient only)

// ============================================================
// PAINT
// ============================================================

function paint() {
    drawBackground();
    drawButton();
    drawIndicators();
    drawSlider();
    drawSeparator();
    drawMeta();
    drawBorder();
}

// --- Background: orange → blue gradient, warm neutral transition ---
function drawBackground() {
    var pg = mgraphics.pattern_create_linear(0, 0, W, 0);
    pg.add_color_stop_rgba(0.00, COL_WARM[0], COL_WARM[1], COL_WARM[2], 1);  // orange
    pg.add_color_stop_rgba(0.40, 0.78, 0.62, 0.40, 1);                       // warm sandy
    pg.add_color_stop_rgba(0.60, 0.38, 0.64, 0.66, 1);                       // cool sage
    pg.add_color_stop_rgba(1.00, COL_COOL[0], COL_COOL[1], COL_COOL[2], 1);  // blue
    mgraphics.set_source(pg);
    mgraphics.rectangle(0, 0, W, H);
    mgraphics.fill();
}

// --- RANDOM button ---
function drawButton() {
    var bgAlpha = isActiveBtn ? 1.0 : (isHoverBtn ? 0.95 : 0.85);

    // Background
    mgraphics.set_source_rgba(1, 1, 1, bgAlpha);
    mgraphics.rectangle(BTN_X, BTN_Y, BTN_W, BTN_H);
    mgraphics.fill();

    // Border
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 1);
    mgraphics.set_line_width(1);
    mgraphics.new_path();
    mgraphics.rectangle(BTN_X + 0.5, BTN_Y + 0.5, BTN_W - 1, BTN_H - 1);
    mgraphics.stroke();

    // Label
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 1);
    mgraphics.select_font_face("Helvetica Neue");
    mgraphics.set_font_size(9);
    var label = "R A N D O M";
    var tw = mgraphics.text_measure(label);
    mgraphics.move_to(BTN_X + (BTN_W - tw[0]) / 2, BTN_Y + (BTN_H + tw[1]) / 2 - 1);
    mgraphics.show_text(label);
}

// --- A / B indicators ---
function drawIndicators() {
    mgraphics.select_font_face("Arial Black");
    mgraphics.set_font_size(22);

    // Compute shared baseline Y from "A" metrics (same for all caps)
    var refH = mgraphics.text_measure("A")[1];
    var baseY = MORPH_Y + refH * 0.35;

    // A
    var aAlpha = (activeSlot === "A") ? 1.0 : 0.25;
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], aAlpha);
    var twa = mgraphics.text_measure("A");
    mgraphics.move_to(IND_A_CX - twa[0] / 2, baseY);
    mgraphics.show_text("A");

    // B — same baseY for perfect alignment
    var bAlpha = (activeSlot === "B") ? 1.0 : 0.25;
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], bAlpha);
    var twb = mgraphics.text_measure("B");
    mgraphics.move_to(IND_B_CX - twb[0] / 2, baseY);
    mgraphics.show_text("B");
}

// --- Morph slider ---
function drawSlider() {
    var thumbX = SLIDER_X1 + morphPos * SLIDER_W;

    // Track line
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 0.4);
    mgraphics.set_line_width(2);
    mgraphics.new_path();
    mgraphics.move_to(SLIDER_X1, MORPH_Y);
    mgraphics.line_to(SLIDER_X2, MORPH_Y);
    mgraphics.stroke();

    // Center tick at 0.5
    var tickX = SLIDER_X1 + 0.5 * SLIDER_W;
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 0.5);
    mgraphics.set_line_width(1);
    mgraphics.new_path();
    mgraphics.move_to(tickX, MORPH_Y - 4);
    mgraphics.line_to(tickX, MORPH_Y + 4);
    mgraphics.stroke();

    // Thumb
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 1);
    mgraphics.rectangle(thumbX - THUMB_W / 2, MORPH_Y - THUMB_H / 2, THUMB_W, THUMB_H);
    mgraphics.fill();
}

// --- Separator line ---
function drawSeparator() {
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 0.8);
    mgraphics.set_line_width(1);
    mgraphics.new_path();
    mgraphics.move_to(0, SEP_Y + 0.5);
    mgraphics.line_to(W, SEP_Y + 0.5);
    mgraphics.stroke();
}

// --- Meta bar (bottom): device name + target ---
function drawMeta() {
    var metaCY = SEP_Y + META_H / 2 + 3;

    // "af.points RANDOMIZER" — left
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 1);
    mgraphics.select_font_face("Helvetica Neue");
    mgraphics.set_font_size(9);
    mgraphics.move_to(12, metaCY);
    mgraphics.show_text("af.points RANDOMIZER");

    // Target name — right
    var tText;
    if (targetName === "NO TARGET") {
        tText = "NO TARGET";
    } else {
        tText = "TARGET: " + targetName.toUpperCase();
    }
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 0.6);
    mgraphics.set_font_size(9);
    var tw = mgraphics.text_measure(tText);
    mgraphics.move_to(W - 12 - tw[0], metaCY);
    mgraphics.show_text(tText);
}

// --- Outer border ---
function drawBorder() {
    mgraphics.set_source_rgba(COL_TEXT[0], COL_TEXT[1], COL_TEXT[2], 1);
    mgraphics.set_line_width(1);
    mgraphics.new_path();
    mgraphics.rectangle(0.5, 0.5, W - 1, H - 1);
    mgraphics.stroke();
}

// ============================================================
// HIT TESTING
// ============================================================

function hitBtn(x, y) {
    return x >= BTN_X && x <= BTN_X + BTN_W &&
           y >= BTN_Y && y <= BTN_Y + BTN_H;
}

function hitSlider(x, y) {
    return x >= SLIDER_X1 - 10 && x <= SLIDER_X2 + 10 &&
           y >= MORPH_Y - 20 && y <= MORPH_Y + 20;
}

// ============================================================
// MOUSE INTERACTION
// ============================================================

function onclick(x, y, but, cmd, shift, caps, opt, ctrl) {
    // Button
    if (hitBtn(x, y)) {
        isActiveBtn = true;
        outlet(0, "bang");
        mgraphics.redraw();
        return;
    }
    // Slider
    if (hitSlider(x, y)) {
        isDragging = true;
        setMorphFromX(x);
        return;
    }
}

function ondrag(x, y, but, cmd, shift, caps, opt, ctrl) {
    if (!but) {
        // Mouse released
        if (isActiveBtn) {
            isActiveBtn = false;
            mgraphics.redraw();
        }
        if (isDragging) {
            isDragging = false;
        }
        return;
    }
    if (isDragging) {
        setMorphFromX(x);
    }
}

function onidle(x, y, but, cmd, shift, caps, opt, ctrl) {
    var prev = isHoverBtn;
    isHoverBtn = hitBtn(x, y);
    if (isHoverBtn !== prev) mgraphics.redraw();
}

function onidleout(x, y, but, cmd, shift, caps, opt, ctrl) {
    if (isHoverBtn) {
        isHoverBtn = false;
        mgraphics.redraw();
    }
}

function setMorphFromX(x) {
    var norm = (x - SLIDER_X1) / SLIDER_W;
    norm = Math.max(0, Math.min(1, norm));
    morphPos = norm;
    outlet(1, morphPos);
    mgraphics.redraw();
}

// ============================================================
// INBOUND MESSAGES FROM ENGINE / LIVE.DIAL
// ============================================================

// indicator(nextSlot) — "A" means next→A so B was just filled, etc.
function indicator(slot) {
    if (slot === "A") {
        activeSlot = "B";      // B was just randomized
    } else if (slot === "B") {
        activeSlot = "A";      // A was just randomized
    } else {
        activeSlot = "none";   // no spawns yet / reset
    }
    mgraphics.redraw();
}

// target(name...) — device name (may contain spaces → multiple args)
function target() {
    var parts = [];
    for (var i = 0; i < arguments.length; i++) {
        parts.push(arguments[i].toString());
    }
    var name = parts.join(" ");
    if (!name || name === "" || name === "no_target") {
        targetName = "NO TARGET";
    } else {
        targetName = name;
    }
    mgraphics.redraw();
}

// set_morph(v) — engine auto-jump after SPAWN
function set_morph(v) {
    morphPos = parseFloat(v);
    if (isNaN(morphPos)) morphPos = 0.5;
    morphPos = Math.max(0, Math.min(1, morphPos));
    mgraphics.redraw();
}

// morph_fb(v) — live.dial feedback (automation / MIDI changes)
function morph_fb(v) {
    morphPos = parseFloat(v);
    if (isNaN(morphPos)) morphPos = 0.5;
    morphPos = Math.max(0, Math.min(1, morphPos));
    mgraphics.redraw();
}

// Ignore unknown messages gracefully
function anything() {}
